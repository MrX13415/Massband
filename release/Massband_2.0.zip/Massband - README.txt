README:

Massband 2.0 beta r26 (c) Oliver Daus 2011
Measuring tape for Minecraft-bukkit Server


Befehle:

  /massband clear oder /mb clr
	Vector-Liste l�schen

  /massband lenght oder /mb l
	zuletzt gemessene l�nge abrufen
	(auch nach dem l�schen der vectorliste)

  /massband switchMode oder /mb sw
	�ndert den Modus zwischen 2D und 3D
	(2D: ignoriet den H�hen-unterschied)


gebrauch:

	Mit dem Holzschwert und mit Rechtsklick einen Block anklicken
	und somit einen Punkt (Vector) hinzuf�gen.
	
	Bei mehr als 2 Punkten (Vectoren) wierd der abstand zwischen
	den einzelnen Vectoren automatich berechnet. 


versions-�nderungen:

	2.0 beta r26:
		- FIX: Befehle in einen Befehl zusammengefasst

	1.9 beta r25:
		- FIX: Befehle nochmal ge�ndert
 
	1.8 beta r23:
		- FIX: Methoden-Signatur ge�ndert
 
	1.7 beta r22:
		- FIX: F�r Minecraft 1.4_1 kompatibel gemacht
		- FIX: Befehle ge�ndert
 
	1.6 beta r19:
		- FIX: Beim 2D-Modus steht jetzt auch 2D nicht 3D
		- ADD: Zeigt nun immer an in welchem modus man ist
		- FIX: Geht nicht mehr in den 2D-Modus zur�ck beim leeren der vectorliste (/vclear)
	
	1.5 beta r17:
		- ADD: Farbiger Nachrichten-Text
	
	1.4 beta r16:
		- ADD: /switchMode (/vsw) Befehl hinzugef�gt
		- FIX: Ignoriert den H�henunterschied (siehe /vsw)

	1.3 beta r15:
		- ADD: Messen von einer Strecke mit mehreren punkten
		- FIX: Es k�nnen jetzt mehrere Benutzer verwenden

	0.2 alpha r2 - 1.2 beta r14:
    		- ADD/FIX: Befehle
   	 	- ADD/FIX: Messen von einer Strecke

	0.1 alpha r1:
    		- init Version
    